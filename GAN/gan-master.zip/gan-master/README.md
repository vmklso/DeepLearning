# Make Your First GAN With PyTorch

python notebooks accompanying the book: [Make Your First GAN With PyTorch](https://www.amazon.com/dp/B085RNKXPD)

blog: [https://makeyourownneuralnetwork.blogspot.com](https://makeyourownneuralnetwork.blogspot.com)
