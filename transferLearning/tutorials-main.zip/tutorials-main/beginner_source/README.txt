Beginner Tutorials
------------------

1. blitz/* and deep_learning_60min_blitz.rst
	Deep Learning with PyTorch: A 60 Minute Blitz
	https://pytorch.org/tutorials/beginner/deep_learning_60min_blitz.html

2. former_torches/* and former_torchies_tutorial.rst
	PyTorch for Former Torch Users
	https://pytorch.org/tutorials/beginner/former_torchies_tutorial.html

3. examples_*/* and pytorch_with_examples.rst
	Learning PyTorch with Examples
	https://pytorch.org/tutorials/beginner/pytorch_with_examples.html

4. transfer_learning_tutorial.py
	Transfer Learning Tutorial
	https://pytorch.org/tutorials/beginner/transfer_learning_tutorial.html

5. nlp/* and deep_learning_nlp_tutorial.rst
	Deep Learning for NLP with Pytorch
	https://pytorch.org/tutorials/beginner/deep_learning_nlp_tutorial.html

6. transformer_translation.py
	Language Translation with Transformers
	https://pytorch.org/tutorials/beginner/transformer_tutorial.html
