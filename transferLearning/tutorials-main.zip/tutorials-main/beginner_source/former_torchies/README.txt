 PyTorch for former Torch users
 ------------------------------
 
1. tensor_tutorial_old.py
	Tensors
	https://pytorch.org/tutorials/beginner/former_torchies/tensor_tutorial_old.html

2. autograd_tutorial_old.py
	Autograd
	https://pytorch.org/tutorials/beginner/former_torchies/autograd_tutorial_old.html

3. nnft_tutorial.py
	nn package
	https://pytorch.org/tutorials/beginner/former_torchies/nnft_tutorial.html

4. parallelism_tutorial.py
	Multi-GPU examples
	https://pytorch.org/tutorials/beginner/former_torchies/parallelism_tutorial.html
