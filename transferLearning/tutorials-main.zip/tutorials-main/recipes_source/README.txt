Recipes
------------------
1. recipes/* and recipes_index.rst
	   PyTorch Recipes
	   https://pytorch.org/tutorials/recipes/recipes_index.html
	   

